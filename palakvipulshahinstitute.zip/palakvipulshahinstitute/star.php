<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>star-page</title>
    <!-- font awseome -->
    <script src="https://kit.fontawesome.com/04cba96299.js" crossorigin="anonymous"></script>
</head>
<body>
    <div align="center" >
        <h3>Rate us: 
            <i class="fa fa-star" ></i>
            <i class="fa fa-star" ></i>
            <i class="fa fa-star" ></i>
            <i class="fa fa-star" ></i>
            <i class="fa fa-star" ></i>
        </h3>
    </div>
        <div align="center">
            <h3>
                Your comment:
                <input type="text" id="text" style="width:50%">
            </h3>
         </div>
        

</body>
</html>