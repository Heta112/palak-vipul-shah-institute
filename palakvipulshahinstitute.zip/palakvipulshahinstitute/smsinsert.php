<?php

	include 'connection.php';
	$num1 = $_POST['num1'];
	$num2 = $_POST['num2'];
	$num3 = $_POST['num3'];
	$num4 = $_POST['num4'];
	$num5 = $_POST['num5'];
	$num6 = $_POST['num6'];
	$num7 = $_POST['num7'];
	$num8 = $_POST['num8'];
	$num9 = $_POST['num9'];
	$num10 = $_POST['num10'];
	$num11 = $_POST['num11'];
	$num12 = $_POST['num12'];
	$num13 = $_POST['num13'];
	$num14 = $_POST['num14'];
	$num15 = $_POST['num15'];
	$num16 = $_POST['num16'];
	$num17 = $_POST['num17'];
	$num18 = $_POST['num18'];
	$num19 = $_POST['num19'];
	$num20 = $_POST['num20'];
	$num21 = $_POST['num21'];
	$num22 = $_POST['num22'];
	$num23 = $_POST['num23'];
	$num24 = $_POST['num24'];
	$num25 = $_POST['num25'];
	$num26 = $_POST['num26'];
	$num27 = $_POST['num27'];
	$num28 = $_POST['num28'];
	$num29 = $_POST['num29'];
	$num30 = $_POST['num30'];
	$num31 = $_POST['num31'];
	$num32 = $_POST['num32'];
	$num33 = $_POST['num33'];
	$num34 = $_POST['num34'];
	$num35 = $_POST['num35'];
	$num36 = $_POST['num36'];
	$num37 = $_POST['num37'];
	$num38 = $_POST['num38'];
	$num39 = $_POST['num39'];
	$num40 = $_POST['num40'];
	$num41 = $_POST['num41'];
	$num42 = $_POST['num42'];
	$num43 = $_POST['num43'];
	$num44 = $_POST['num44'];
	$num45 = $_POST['num45'];
	$num46 = $_POST['num46'];
	$num47 = $_POST['num47'];
	$num48 = $_POST['num48'];
	$num49 = $_POST['num49'];
	$num50 = $_POST['num50'];
	$num51 = $_POST['num51'];
	$num52 = $_POST['num52'];
	$num53 = $_POST['num53'];
	$num54 = $_POST['num54'];
	$num55 = $_POST['num55'];
	$num56 = $_POST['num56'];
	$num57 = $_POST['num57'];
	$num58 = $_POST['num58'];
	$num59 = $_POST['num59'];
	$num60 = $_POST['num60'];
	$num61 = $_POST['num61'];
	$num62 = $_POST['num62'];
	$num63 = $_POST['num63'];
	$num64 = $_POST['num64'];
	$num65 = $_POST['num65'];
	$num66 = $_POST['num66'];
	$num67 = $_POST['num67'];
	$num68 = $_POST['num68'];
	$num69 = $_POST['num69'];
	$num70 = $_POST['num70'];
	$num71 = $_POST['num71'];
	$num72 = $_POST['num72'];
	$num73 = $_POST['num73'];
	$num74 = $_POST['num74'];
	$num75 = $_POST['num75'];
	$num76 = $_POST['num76'];
	$num77 = $_POST['num77'];
	$num78 = $_POST['num78'];
	$num79 = $_POST['num79'];
	$num80 = $_POST['num80'];
	$num81 = $_POST['num81'];
	$num82 = $_POST['num82'];
	$num83 = $_POST['num83'];
	$num84 = $_POST['num84'];
	$num85 = $_POST['num85'];
	$num86 = $_POST['num86'];
	$num87 = $_POST['num87'];
	$num88 = $_POST['num88'];
	$num89 = $_POST['num89'];
	$num90 = $_POST['num90'];
    $num91 = $_POST['num91'];
	$num92 = $_POST['num92'];
	$num93 = $_POST['num93'];
	$num94 = $_POST['num94'];
	$num95 = $_POST['num95'];
	$num96 = $_POST['num96'];
	$num97 = $_POST['num97'];
	$num98 = $_POST['num98'];
	$num99 = $_POST['num99'];
	$num100 = $_POST['num100'];
    $msg = $_POST['message'];
	date_default_timezone_get();
	$cdate = date("y.m.d ");
	$ctime = date("h:i:sa");
	

	
	$sql = "INSERT INTO pvs (number,text,date,time) VALUES ('$num1','$msg','$cdate','$ctime'),('$num2','$msg','$cdate','$ctime'),
	('$num3','$msg','$cdate','$ctime'),('$num4','$msg','$cdate','$ctime'),('$num5','$msg','$cdate','$ctime'),('$num6','$msg','$cdate','$ctime'),('$num7','$msg','$cdate','$ctime'),
	('$num8','$msg','$cdate','$ctime'),('$num9','$msg','$cdate','$ctime'),('$num10','$msg','$cdate','$ctime'),('$num11','$msg','$cdate','$ctime'),('$num12','$msg','$cdate','$ctime'),
	('$num13','$msg','$cdate','$ctime'),('$num14','$msg','$cdate','$ctime'),('$num15','$msg','$cdate','$ctime'),('$num16','$msg','$cdate','$ctime'),('$num17','$msg','$cdate','$ctime'),
	('$num18','$msg','$cdate','$ctime'),('$num19','$msg','$cdate','$ctime'),('$num20','$msg','$cdate','$ctime'),('$num21','$msg','$cdate','$ctime'),('$num22','$msg','$cdate','$ctime'),
	('$num23','$msg','$cdate','$ctime'),('$num24','$msg','$cdate','$ctime'),('$num25','$msg','$cdate','$ctime'),('$num26','$msg','$cdate','$ctime'),('$num27','$msg','$cdate','$ctime'),
	('$num28','$msg','$cdate','$ctime'),('$num29','$msg','$cdate','$ctime'),('$num30','$msg','$cdate','$ctime'),('$num31','$msg','$cdate','$ctime'),('$num32','$msg','$cdate','$ctime'),
	('$num33','$msg','$cdate','$ctime'),('$num34','$msg','$cdate','$ctime'),('$num35','$msg','$cdate','$ctime'),('$num36','$msg','$cdate','$ctime'),('$num37','$msg','$cdate','$ctime'),
	('$num38','$msg','$cdate','$ctime'),('$num39','$msg','$cdate','$ctime'),('$num40','$msg','$cdate','$ctime'),('$num41','$msg','$cdate','$ctime'),('$num42','$msg','$cdate','$ctime'),
	('$num43','$msg','$cdate','$ctime'),('$num44','$msg','$cdate','$ctime'),('$num45','$msg','$cdate','$ctime'),('$num46','$msg','$cdate','$ctime'),('$num47','$msg','$cdate','$ctime'),
	('$num48','$msg','$cdate','$ctime'),('$num49','$msg','$cdate','$ctime'),('$num50','$msg','$cdate','$ctime'),('$num51','$msg','$cdate','$ctime'),('$num52','$msg','$cdate','$ctime'),
	('$num53','$msg','$cdate','$ctime'),('$num54','$msg','$cdate','$ctime'),('$num55','$msg','$cdate','$ctime'),('$num56','$msg','$cdate','$ctime'),('$num57','$msg','$cdate','$ctime'),
	('$num58','$msg','$cdate','$ctime'),('$num59','$msg','$cdate','$ctime'),('$num60','$msg','$cdate','$ctime'),('$num61','$msg','$cdate','$ctime'),('$num62','$msg','$cdate','$ctime'),
	('$num63','$msg','$cdate','$ctime'),('$num64','$msg','$cdate','$ctime'),('$num65','$msg','$cdate','$ctime'),('$num66','$msg','$cdate','$ctime'),('$num67','$msg','$cdate','$ctime'),
	('$num68','$msg','$cdate','$ctime'),('$num69','$msg','$cdate','$ctime'),('$num70','$msg','$cdate','$ctime'),('$num71','$msg','$cdate','$ctime'),('$num72','$msg','$cdate','$ctime'),
	('$num73','$msg','$cdate','$ctime'),('$num74','$msg','$cdate','$ctime'),('$num75','$msg','$cdate','$ctime'),('$num76','$msg','$cdate','$ctime'),('$num77','$msg','$cdate','$ctime'),
	('$num78','$msg','$cdate','$ctime'),('$num79','$msg','$cdate','$ctime'),('$num80','$msg','$cdate','$ctime'),('$num81','$msg','$cdate','$ctime'),('$num82','$msg','$cdate','$ctime'),
	('$num83','$msg','$cdate','$ctime'),('$num84','$msg','$cdate','$ctime'),('$num85','$msg','$cdate','$ctime'),('$num86','$msg','$cdate','$ctime'),('$num87','$msg','$cdate','$ctime'),
	('$num88','$msg','$cdate','$ctime'),('$num89','$msg','$cdate','$ctime'),('$num90','$msg','$cdate','$ctime'),('$num91','$msg','$cdate','$ctime'),('$num92','$msg','$cdate','$ctime'),
	('$num93','$msg','$cdate','$ctime'),('$num94','$msg','$cdate','$ctime'),('$num95','$msg','$cdate','$ctime'),('$num96','$msg','$cdate','$ctime'),('$num97','$msg','$cdate','$ctime'),
	('$num98','$msg','$cdate','$ctime'),('$num99','$msg','$cdate','$ctime'),('$num100','$msg','$cdate','$ctime')";
	
	if(!mysqli_query($con,$sql))
	{
	
		echo ("message not successfully inserted");
	
	}
	else
	{
		
		echo ("message successfully inserted");
		
	}

	header("refresh:5; url=front.php");
?>