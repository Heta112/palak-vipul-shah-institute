
<!DOCTYPE html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body {
  font-family: Arial;
  color: white;
}

.split {
  height: 100%;
  width: 50%;
  position: fixed;
  z-index: 1;
  top: 0;
  overflow-x: hidden;
  padding-top: 20px;
}

.left {
  left: 0;
  
}

.right {
  right: 0;
  
}

.centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
}

</style>

</head>
<body>
    <?php
    
    include 'connection.php';
    
    ?>
    
    
	<div class="split left">
		<div class="centered">
			<form action ="insert.php" method="POST" style="text-align: center">
	
				<input type="number" name="num1" placeholder="enter number1"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num2" placeholder="enter number2"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num3" placeholder="enter number3"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num4" placeholder="enter number4"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num5" placeholder="enter number5"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num6" placeholder="enter number6"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num7" placeholder="enter number7"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num8" placeholder="enter number8"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num9" placeholder="enter number9"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num10" placeholder="enter number10" min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
	            <input type="number" name="num11" placeholder="enter number11"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num12" placeholder="enter number12"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num13" placeholder="enter number13"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num14" placeholder="enter number14"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num15" placeholder="enter number15"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num16" placeholder="enter number16"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num17" placeholder="enter number17"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num18" placeholder="enter number18"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num19" placeholder="enter number19"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num20" placeholder="enter number20" min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
				
				<input type="number" name="num21" placeholder="enter number21"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num22" placeholder="enter number22"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num23" placeholder="enter number23"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num24" placeholder="enter number24"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num25" placeholder="enter number25"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num26" placeholder="enter number26"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num27" placeholder="enter number27"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num28" placeholder="enter number28"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num29" placeholder="enter number29"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num30" placeholder="enter number30" min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
				
				<input type="number" name="num31" placeholder="enter number31"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num32" placeholder="enter number32"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num33" placeholder="enter number33"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num34" placeholder="enter number34"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num35" placeholder="enter number35"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num36" placeholder="enter number36"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num37" placeholder="enter number37"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num38" placeholder="enter number38"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num39" placeholder="enter number39"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num40" placeholder="enter number40" min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
				
				<input type="number" name="num41" placeholder="enter number41"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num42" placeholder="enter number42"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num43" placeholder="enter number43"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num44" placeholder="enter number44"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num45" placeholder="enter number45"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num46" placeholder="enter number46"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num47" placeholder="enter number47"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num48" placeholder="enter number48"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num49" placeholder="enter number49"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num50" placeholder="enter number50" min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
				
				<input type="number" name="num51" placeholder="enter number51"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num52" placeholder="enter number52"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num53" placeholder="enter number53"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num54" placeholder="enter number54"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num55" placeholder="enter number55"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num56" placeholder="enter number56"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num57" placeholder="enter number57"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num58" placeholder="enter number58"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num59" placeholder="enter number59"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num60" placeholder="enter number60" min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
				
				<input type="number" name="num61" placeholder="enter number61"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num62" placeholder="enter number62"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num63" placeholder="enter number63"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num64" placeholder="enter number64"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num65" placeholder="enter number65"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num66" placeholder="enter number66"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num67" placeholder="enter number67"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num68" placeholder="enter number68"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num69" placeholder="enter number69"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num70" placeholder="enter number70" min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
				
				<input type="number" name="num71" placeholder="enter number71"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num72" placeholder="enter number72"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num73" placeholder="enter number73"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num74" placeholder="enter number74"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num75" placeholder="enter number75"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num76" placeholder="enter number76"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num77" placeholder="enter number77"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num78" placeholder="enter number78"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num79" placeholder="enter number79"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num80" placeholder="enter number80" min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
				
				<input type="number" name="num81" placeholder="enter number81"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num82" placeholder="enter number82"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num83" placeholder="enter number83"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num84" placeholder="enter number84"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num85" placeholder="enter number85"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num86" placeholder="enter number86"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num87" placeholder="enter number87"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num88" placeholder="enter number88"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num89" placeholder="enter number89"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num90" placeholder="enter number90" min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
				
				<input type="number" name="num91" placeholder="enter number91"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num92" placeholder="enter number92"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num93" placeholder="enter number93"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num94" placeholder="enter number94"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num95" placeholder="enter number95"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num96" placeholder="enter number96"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num97" placeholder="enter number97"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num98" placeholder="enter number98"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num99" placeholder="enter number99"  min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
	
				<input type="number" name="num100" placeholder="enter number100" min="1000000000" maxlength="10" pattern="[1-9]{1}[0-9]{9}" required=""><br><br>
				
				
				
		</div>
	</div>

	<div class="split right">
		<div class="centered">
			<input type="textarea" name="message" placeholder="Write message" required=""><br><br>

			<input type="submit" name="submit" value="SEND MESSAGE"  >
			
			</form>
			<br/><br/><br/><br/><br/>
			<a href="logout.php">Log out</a>
		</div>
			
	</div>

	
</body>
</html>