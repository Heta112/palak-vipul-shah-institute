<!DOCTYPE html>
<html class="no-js" lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>rating</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- CSS Files-->
	  <link rel="stylesheet" href="css/style1.css">
	  <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
	  <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
    <!-- font awesome -->
    <script src="https://kit.fontawesome.com/04cba96299.js" crossorigin="anonymous"></script>

    </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="head">
            <div  class="container">
               <div class="row ">
                  <div  class="col-md-7">
                     <ul class="email_call">
                        <li><a href="#"><img src="icon/2.png" alt="#"/>(+91)9979504386</a></li>
                        <li><a href="#"><img src="icon/1.png" alt="#"/>palakvipulshahinstitute@gmail.com</a></li>
                     </ul>
                  </div>
                  <div  class="col-md-5">
                     <ul class="social_icon">
                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></i></a></li>
                        <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin-square" aria-hidden="true"></i></i></a></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
         <div class="header-top">
            <div class="header">
               <div class="container-fluid">
                  <div class="row">
                     <div class="col-xl-2 col-lg-2 col-md-2 col-sm-2 col logo_section">
                        <div class="full">
                           <div class="center-desk">
                              <div class="logo">
                                 <a href="index.html"><img src="images/logo.jpg" alt="#" /></a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10">

                     <div class="menu-area">
                           <div class="limit-box">
                              <nav class="main-menu">
                                 <ul class="menu-area-main">
                                    <li class="active"> <a href="index.html">Home</a> </li>
                                    <li class="active"> <a href="course.html">Course</a> </li>
                                    <li class="active"> <a href="aboutus.html">About us</a> </li>
                                    <li class="active"> <a href="gallary.html">Gallary</a> </li>
                                    <li class="active"> <a href="rating.php">Review</a> </li>
                                    <li class="active"> <a href="">blog</a> </li>
                                    <li class="active"> <a href="contactus.html">Contact us</a> </li>
                                 </ul>
                              </nav>
                           </div>
                        </div>
                     </div>   
                  </div>
               </div>
            </div>
            <!-- end header inner -->
            <!-- end header -->
            <div style="padding:100px;">
               <h3 style="padding:10px 50px 0px 70px;">Rate us: 
               <i class="fa fa-star" data-index="0"></i>
               <i class="fa fa-star" data-index="1"></i>
               <i class="fa fa-star" data-index="2"></i>
               <i class="fa fa-star" data-index="3"></i>
               <i class="fa fa-star" data-index="4"></i>
               </h3>
            
            <!-- <div style="padding:10px 50px 0px 70px;">
               <h3>
                Your comment:  <input type="text" id="text" style="width:50%">
               </h3>
            </div>
             --></div>

            <script  src="https://code.jquery.com/jquery-3.6.0.min.js"  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="   crossorigin="anonymous"></script>
            <script>
               var ratedIndex=-1;
               var stars = $('.fa-star');
               
               $(document).ready(function(){
               resetStarColors();
               
               $('.fa-star').on('click', function(){
                  ratedIndex = parseInt($(this).data('index'));
                  console.log("ratedIndex=" + ratedIndex);
               }); 

               $('.fa-star').mouseover(function(){
                  resetStarColors();

                  var currentIndex = parseInt($(this).data('index'));
                     for(var i=0; i<=currentIndex; i++)
                        stars.select(i).css('color','yellow');
               });
               $('.fa-star').mouseleave(function(){
                  resetStarColors();

                  if(ratedIndex != -1)
                     for(var i=0; i <= ratedIndex; i++)
                        stars.select(i).css('color','yellow');
               });
               });

               function resetStarColors(){
                  $('.fa-star').css('color','white')
               }
            </script>
         </div>
      </header>
	  
     
      <footer>
	  <div style="background-color:black; width:100% " class="row">
	<div class="twelve columns">
		<div class="centersectiontitle">
			<h4 style="color:white; background-color:black"> Our Branches</h4>
		</div>
	</div>
	<div class="four columns">
		<h5 style="color:white">Sattelite</h5>
		<p style="color:white">
			 Swine short ribs meatball irure bacon nulla pork belly cupidatat meatloaf cow. Nulla corned beef sunt ball tip, qui bresaola enim jowl. Capicola short ribs minim salami nulla nostrud pastrami.
		</p>
	</div>
	<div class="four columns">
		<h5 style="color:white">Gurukul</h5>
		<p style="color:white">
			 Swine short ribs meatball irure bacon nulla pork belly cupidatat meatloaf cow. Nulla corned beef sunt ball tip, qui bresaola enim jowl. Capicola short ribs minim salami nulla nostrud pastrami.
		</p>
	</div>
	<div class="four columns">
		<h5 style="color:white">Dharnidhar</h5>
		<p style="color:white">
			 Swine short ribs meatball irure bacon nulla pork belly cupidatat meatloaf cow. Nulla corned beef sunt ball tip, qui bresaola enim jowl. Capicola short ribs minim salami nulla nostrud pastrami.
		</p>
	</div>
</div>
	  </footer>
      <!-- three box -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/plugin.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
         // This example adds a marker to indicate the position of Bondi Beach in Sydney,
         // Australia.
         function initMap() {
             var map = new google.maps.Map(document.getElementById('map'), {
                 zoom: 11,
                 center: {
                     lat: 40.645037,
                     lng: -73.880224
                 },
             });
         
             var image = 'images/maps-and-flags.png';
             var beachMarker = new google.maps.Marker({
                 position: {
                     lat: 40.645037,
                     lng: -73.880224
                 },
                 map: map,
                 icon: image
             });
         }
      </script>
      <!-- google map js -->
      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA8eaHt9Dh5H57Zh0xVTqxVdBFCvFMqFjQ&callback=initMap"></script>
      <!-- end google map js -->
   </body>
</html> 